# An subpolicy enabling some of the
# post-quantum and hybrid algorithms
# currently available in RHEL-9.
# Note that not all the backends support all the algorithms.

### Oracle Linux groups
group = +MLKEM1024
group = +MLKEM768
group = +MLKEM512
###
 
group = +MLKEM1024-X448
group = +P384-MLKEM1024
group = +P256-MLKEM768
group = +MLKEM768-X25519

sign = +MLDSA87-ED448
sign = +MLDSA65-ED25519
sign = +MLDSA87
sign = +MLDSA65
sign = +MLDSA44

key_exchange = +KEM-ECDH
